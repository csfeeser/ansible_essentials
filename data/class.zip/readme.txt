ansible-playbook playbook.yml -i inventory.yml -k
